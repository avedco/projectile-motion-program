import sys
from PyQt5.QtWidgets import *
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from numpy import deg2rad, cos, sin, tan, sqrt, linspace


ladData = 0
larData = 0
uData = 0
hData = 0
gData = 0
dtData = 0
PData = 0
rData = 0
MData = 0
cdData = 0
xdrag = []
ydrag = []
xs = []
ys = []
xa = 0
ya = 0
xa_drag = 0
ya_drag = 0
x_bounding = [0]
y_bounding = [0]
Ts = [0]
TsDrag = [0]
vxs = [0]
vdxs = [0]
vys = [0]
vdys = [0]
vs = [0]
vds = [0]
tracker = "Y against X"

class Task9App(QMainWindow):

    def __init__(self):
        super().__init__()
        self.left = 10
        self.top = 10
        self.title = 'Task 9'
        self.width = 800
        self.height = 400
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)

        centralWidget = QWidget(self)
        self.setCentralWidget(centralWidget)

        layout = QGridLayout()
        centralWidget.setLayout(layout)
        self.m = PlotCanvas(self, width=5, height=4)
        layout.addWidget(self.m, 0, 0, 10, 1)

        ladLabel = QLabel("Launch Angle (Degrees)", self)
        lad = QDoubleSpinBox(self)
        ladLabel.setBuddy(lad)
        lad.setMaximum(90)
        ladLabel.resize(150,20)

        lad.valueChanged.connect(self.getLadData)
        lad.valueChanged.connect(self.calc)
        uLabel = QLabel("Launch speed", self)
        u = QDoubleSpinBox(self)
        uLabel.setBuddy(u)

        u.valueChanged.connect(self.getUData)
        u.valueChanged.connect(self.calc)
        hLabel = QLabel("Launch height", self)
        h = QDoubleSpinBox(self)
        hLabel.setBuddy(h)

        h.valueChanged.connect(self.getHData)
        h.valueChanged.connect(self.calc)
        gLabel = QLabel("Strength of gravity", self)
        g = QDoubleSpinBox(self)
        gLabel.setBuddy(g)
        gLabel.resize(150,20)

        g.valueChanged.connect(self.getGData)
        g.valueChanged.connect(self.calc)
        dtLabel = QLabel("Time increment", self)
        dt = QDoubleSpinBox(self)
        dt.setDecimals(3)
        dtLabel.setBuddy(dt)

        dt.valueChanged.connect(self.getdtData)
        dt.valueChanged.connect(self.calc)
        pLabel = QLabel("Air density", self)
        p = QDoubleSpinBox(self)
        pLabel.setBuddy(p)

        p.valueChanged.connect(self.getPData)
        p.valueChanged.connect(self.calc)
        rLabel = QLabel("Cross sectional area", self)
        r = QDoubleSpinBox(self)
        r.setDecimals(4)
        rLabel.resize(150,20)
        rLabel.setBuddy(r)

        r.valueChanged.connect(self.getrData)
        r.valueChanged.connect(self.calc)
        mLabel = QLabel("Mass (kg)", self)
        m = QDoubleSpinBox(self)
        mLabel.setBuddy(m)

        m.valueChanged.connect(self.getMData)
        m.valueChanged.connect(self.calc)
        cdLabel = QLabel("Drag coefficient", self)
        cd = QDoubleSpinBox(self)
        cdLabel.setBuddy(cd)

        cd.valueChanged.connect(self.getcdData)
        cd.valueChanged.connect(self.calc)
        save = QPushButton("Save graph", self)

        save.clicked.connect(self.save)
        choice = QComboBox(self)
        choice.currentTextChanged.connect(self.change)
        choice.resize(120,20)
        list = ["Y against X", "Y against T", "Vx against T", "Vy against T", "V against T"]
        choice.addItems(list)

        layout.addWidget(ladLabel, 0, 1)
        layout.addWidget(lad, 0, 2)
        layout.addWidget(uLabel, 1, 1)
        layout.addWidget(u, 1, 2)
        layout.addWidget(hLabel, 2, 1)
        layout.addWidget(h, 2, 2)
        layout.addWidget(gLabel, 3, 1)
        layout.addWidget(g, 3, 2)
        layout.addWidget(dtLabel, 4, 1)
        layout.addWidget(dt, 4, 2)
        layout.addWidget(pLabel, 5, 1)
        layout.addWidget(p, 5, 2)
        layout.addWidget(rLabel, 6, 1)
        layout.addWidget(r, 6, 2)
        layout.addWidget(mLabel, 7, 1)
        layout.addWidget(m, 7, 2)
        layout.addWidget(cdLabel, 8, 1)
        layout.addWidget(cd, 8, 2)
        layout.addWidget(save, 9, 1)
        layout.addWidget(choice, 9, 2)
        self.show()

    def getLadData(self, value):
        global ladData
        ladData = value

    def getUData(self, value):
        global uData
        uData = value

    def getHData(self, value):
        global hData
        hData = value

    def getGData(self, value):
        global gData
        gData = value

    def getdtData(self, value):
        global dtData
        dtData = value

    def getPData(self, value):
        global PData
        PData = value

    def getrData(self, value):
        global rData
        rData = value

    def getMData(self, value):
        global MData
        MData = value

    def getcdData(self, value):
        global cdData
        cdData = value

    def save(self):
        options = QFileDialog.Options()
        filePath, _ = QFileDialog.getSaveFileName(self, "Save Plot", "", "PNG Files (*.png);;All Files (*)",options=options)
        if filePath:
            # Save the plot to the specified file path
            self.m.figure.savefig(filePath)


    def change(self, text):
        global tracker
        tracker = text
        self.calc()

    def calc(self):
        global xs, ys, xa, ya, xdrag, ydrag, xa_drag, ya_drag, x_bounding, y_bounding, Ts, TsDrag, vxs, vdxs, vys, vdys, vs, vds
        larData = deg2rad(ladData)
        if uData > 0 and gData > 0:
            r = ((uData ** 2) / gData) * (sin(larData) * cos(larData) + cos(larData) * sqrt(
                (sin(larData)) ** 2 + ((2 * gData * hData) / (uData ** 2))))
            xs = linspace(0, r, num=200)
            t = r / (uData * cos(larData))
            Ts = linspace(0, t, num=200)
            ys = []
            vxs = []
            vys = []
            vs = [uData]

            uy = uData*sin(larData)

            for i in range(len(xs)):
                ys.append(hData + xs[i] * tan(larData) - (gData / (2 * uData ** 2)) * (1 + (tan(larData)) ** 2) * xs[i] ** 2)
                vx = uData*cos(larData)
                vy = uy -gData*Ts[i]
                if i > 0:
                    v = sqrt(vx**2 + vy**2)
                    vs.append(v)
                vxs.append(vx)
                vys.append(vy)


            xa = ((uData ** 2) / gData) * sin(larData) * cos(larData)
            ya = hData + ((uData ** 2) / (2 * gData)) * (sin(larData)) * (sin(larData))

            x_impact = sqrt((2 * uData ** 2 * hData + (uData ** 4 / gData)) / gData)
            x_bounding = linspace(0.0, x_impact, num=200)
            y_bounding = []
            for i in range(len(x_bounding)):
                y_bounding.append(
                    hData + ((uData ** 2) / (2 * gData)) - ((gData * (x_bounding[i] ** 2)) / (2 * (uData ** 2))))

        if uData > 0 and gData > 0 and dtData > 0 and MData > 0:
            ux = uData * cos(larData)
            uy = uData * sin(larData)

            k = (0.5 * cdData * PData * rData) / MData

            ax = -(ux / uData) * k * uData ** 2
            ay = -gData - ((uy / uData) * k * uData ** 2)

            Tdrag = 0
            x = 0
            y = hData
            xdrag = [x]
            ydrag = [y]
            TsDrag = [Tdrag]
            vdxs = [ux]
            vdys = [uy]
            vds = [uData]
            counter = 0
            while y >= 0:
                if counter > 0:
                    ax = -(ux / (sqrt(ux**2+uy**2))) * k * (sqrt(ux**2+uy**2)) ** 2
                    ay = -gData - ((uy / (sqrt(ux**2+uy**2))) * k * (sqrt(ux**2+uy**2)) ** 2)

                ux += ax * dtData
                uy += ay * dtData

                vdxs.append(ux)
                vdys.append(uy)
                vds.append(sqrt(ux**2+uy**2))

                x += ux * dtData
                y += uy * dtData
                Tdrag += dtData
                counter +=1

                xdrag.append(x)
                ydrag.append(y)
                TsDrag.append(Tdrag)


            ya_drag = max(ydrag)
            i = ydrag.index(ya_drag)
            xa_drag = xdrag[i]

        self.m.plot(xs, ys, xa, ya, xdrag, ydrag, xa_drag, ya_drag, x_bounding, y_bounding, Ts, TsDrag, vxs, vdxs,
                    vys, vdys, vs, vds)

class PlotCanvas(FigureCanvas):
    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        FigureCanvas.__init__(self, fig)
        self.setParent(parent)
        FigureCanvas.setSizePolicy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)

    def plot(self, xs, ys, xa, ya, xdrag, ydrag, dxa, dya, x_bounding, y_bounding, Ts, TsDrag, vxs, vdxs, vys, vdys,
             vs, vds):
        global tracker
        self.axes.clear()
        if tracker == "Y against X":
            self.axes.plot(xs, ys, c="#006D6F", label = "No drag")
            self.axes.scatter([xa], [ya], c="red", marker="1", zorder=5, s = 40)
            self.axes.plot(xdrag, ydrag, c="#990000", label = "Drag")
            self.axes.scatter([dxa], [dya], c="c", marker="1", zorder=5, s = 40)
            self.axes.plot(x_bounding, y_bounding, lw=2, linestyle='--', color='#7F00FF', zorder=2)
            self.axes.set_title("Y against X")
            self.axes.legend()
            self.axes.set_xlim(left=0)
            self.axes.set_ylim(bottom=0)
        elif tracker == "Y against T":
            self.axes.plot(Ts, ys, c="#006D6F", label = "Drag")
            self.axes.plot(TsDrag, ydrag, c="#990000", label = "No drag")
            self.axes.set_title("Y against T")
            self.axes.legend()
            self.axes.set_xlim(left=0)
            self.axes.set_ylim(bottom=0)
        elif tracker == "Vx against T":
            self.axes.plot(Ts, vxs, c="#006D6F", label = "No drag")
            self.axes.plot(TsDrag, vdxs, c="#990000", label = "Drag")
            self.axes.set_title("Vx against T")
            self.axes.legend()
            self.axes.set_xlim(left=0)
            self.axes.set_ylim(bottom=0)
        elif tracker == "Vy against T":
            self.axes.plot(Ts, vys, c="#006D6F", label = "No drag")
            self.axes.plot(TsDrag, vdys, c="#990000", label = "Drag")
            self.axes.set_title("Vy against T")
            self.axes.legend()
            self.axes.set_xlim(left=0)
        elif tracker == "V against T":
            self.axes.plot(Ts, vs, c="#006D6F", label = "No drag")
            self.axes.plot(TsDrag, vds, c="#990000", label = "Drag")
            self.axes.set_title("V against T")
            self.axes.legend()
            self.axes.set_xlim(left=0)
            self.axes.set_ylim(bottom=0)

        self.draw()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Task9App()
    window.show()
    sys.exit(app.exec_())