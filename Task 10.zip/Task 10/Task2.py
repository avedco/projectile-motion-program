import sys
from PyQt5.QtWidgets import *
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from numpy import deg2rad, cos, sin, tan, sqrt, format_float_positional

ladData = 0
larData = 0
uData = 0
hData = 0
gData = 0

ys = [0]
xs = [0]

class Task2App(QMainWindow):

    def __init__(self):
        super().__init__()
        self.left = 10
        self.top = 10
        self.title = 'Task 2'
        self.width = 800
        self.height = 400
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        centralWidget = QWidget(self)
        self.setCentralWidget(centralWidget)

        layout = QGridLayout()
        centralWidget.setLayout(layout)
        self.m = PlotCanvas(self, width=5, height=4)
        layout.addWidget(self.m, 0, 0, 10, 1)
        ladLabel = QLabel("Launch Angle (Degrees)", self)
        lad = QDoubleSpinBox(self)
        ladLabel.setBuddy(lad)
        ladLabel.resize(150,20)
        layout.addWidget(ladLabel, 0, 1)
        layout.addWidget(lad, 0, 2)
        lad.valueChanged.connect(self.getLadData)
        lad.valueChanged.connect(self.calc)
        uLabel = QLabel("Launch speed", self)
        u = QDoubleSpinBox(self)
        uLabel.setBuddy(u)
        layout.addWidget(uLabel, 1, 1)
        layout.addWidget(u, 1, 2)
        u.valueChanged.connect(self.getUData)
        u.valueChanged.connect(self.calc)
        hLabel = QLabel("Launch height", self)
        h = QDoubleSpinBox(self)
        hLabel.setBuddy(h)
        layout.addWidget(hLabel, 2, 1)
        layout.addWidget(h, 2, 2)
        h.valueChanged.connect(self.getHData)
        h.valueChanged.connect(self.calc)
        gLabel = QLabel("Strength of gravity", self)
        g = QDoubleSpinBox(self)
        gLabel.setBuddy(g)
        gLabel.resize(150,20)
        layout.addWidget(gLabel, 3, 1)
        layout.addWidget(g, 3, 2)
        g.valueChanged.connect(self.getGData)
        g.valueChanged.connect(self.calc)
        self.rLabel = QLabel("Range:", self)
        layout.addWidget(self.rLabel, 4, 1)

        self.tLabel = QLabel("Time of flight:", self)
        self.tLabel.resize(200,20)
        layout.addWidget(self.tLabel, 5, 1)

        self.show()

    def getLadData(self, value):
        global ladData
        ladData = value

    def getUData(self, value):
        global uData
        uData = value

    def getHData(self, value):
        global hData
        hData = value

    def getGData(self, value):
        global gData
        gData = value

    def calc(self):
        global xs, ys
        global xa, ya
        global TData
        xs.clear()
        ys.clear()
        larData = deg2rad(ladData)

        if gData >0  and larData>0 and uData >0:
            rData = ((uData*uData)/gData)*(sin(larData)*cos(larData)+cos(larData)*sqrt(sin(larData)*sin(larData)+(2*gData*hData)/(uData*uData)))
            TData = rData/(uData*cos(larData))
            for i in range(51):
                x = rData*i*0.02
                xs.append(x)
                y = hData + x * tan(larData) - (gData / (2 * uData * uData)) * (1 + tan(larData) * tan(larData)) * x * x
                ys.append(y)
            xa = ((uData*uData)/gData)*sin(larData)*cos(larData)
            ya = hData + ((uData*uData)/(2*gData))*sin(larData)*sin(larData)
            self.m.plot(xs, ys)
            xac = format_float_positional(xa, precision=3, unique=False, fractional=False, trim='k')
            yac = format_float_positional(ya, precision=3, unique=False, fractional=False, trim='k')
            self.m.plotA([xa], [ya], label = f"Apogee {str(xac) + ', ' + str(yac)}")

            self.rLabel.setText(f"Range: {format_float_positional(rData, precision=2, unique=False, fractional=False, trim='k')}")
            self.tLabel.setText(f"Time of flight: {format_float_positional(TData, precision=2, unique=False, fractional=False, trim='k')}")

class PlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        FigureCanvas.__init__(self, fig)
        self.setParent(parent)
        FigureCanvas.setSizePolicy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)

    def plot(self, xs, ys):
        self.axes.clear()
        self.axes.plot(xs, ys, "k", label='Trajectory')
        self.axes.set_xlim(left=0, right=(1.1*max(xs)))
        self.axes.set_ylim(bottom=0, top=(1.1*max(ys)))
        self.draw()

    def plotA(self, xa, ya, label):
        self.axes.plot(xa, ya, "ro", label=label)
        self.axes.set_xlim(left=0)
        self.axes.set_ylim(bottom=0)
        self.axes.legend(loc='upper center', bbox_to_anchor=(0.5, 1.15), ncol=1)  # Add the legend to the plot
        self.draw()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Task2App()
    sys.exit(app.exec_())