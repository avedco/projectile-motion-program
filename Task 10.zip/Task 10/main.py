import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QPushButton, QStackedWidget, QLabel, QHBoxLayout
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
from Task1 import Task1App
from Task2 import Task2App
from Task3 import Task3App
from Task4 import Task4App
from Task5 import Task5App
from Task6 import Task6App
from Task7 import Task7App
from Task8 import Task8App
from Task9 import Task9App

class MainApp(QMainWindow):

    def __init__(self):
        super().__init__()
        self.left = 10
        self.top = 10
        self.title = 'Task 10'
        self.width = 800
        self.height = 400
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)

        # Create central widget and main layout
        centralWidget = QWidget(self)
        self.setCentralWidget(centralWidget)
        self.main_layout = QVBoxLayout()  # Main vertical layout for the window

        # Create a horizontal layout for the buttons
        self.button_layout = QHBoxLayout()
        self.main_layout.addLayout(self.button_layout)  # Add button layout to the main layout

        # Create a placeholder label with larger and centered text
        self.placeholder = QLabel("Select a task", self)
        font = QFont()
        font.setPointSize(20)  # Set font size
        self.placeholder.setFont(font)
        self.placeholder.setAlignment(Qt.AlignCenter)  # Center align text
        self.main_layout.addWidget(self.placeholder)  # Add placeholder label to the main layout

        # Create buttons to switch tasks
        self.create_buttons(self.button_layout)

        centralWidget.setLayout(self.main_layout)  # Set the main layout to the central widget

        self.show()

    def create_buttons(self, layout):
        buttons = [
            ("Task 1", 0),
            ("Task 2", 1),
            ("Task 3", 2),
            ("Task 4", 3),
            ("Task 5", 4),
            ("Task 6", 5),
            ("Task 7", 6),
            ("Task 8", 7),
            ("Task 9", 8)
        ]

        for text, index in buttons:
            button = QPushButton(text, self)
            button.clicked.connect(lambda _, idx=index: self.show_task(idx))
            layout.addWidget(button)

    def show_task(self, index):
        # Initialize and add QStackedWidget if not already done
        if not hasattr(self, 'stacked_widget'):
            self.stacked_widget = QStackedWidget()
            self.main_layout.addWidget(self.stacked_widget)  # Add stacked widget to the layout
            # Create and add task widgets to the stacked widget
            self.task1_widget = Task1App()
            self.task2_widget = Task2App()
            self.task3_widget = Task3App()
            self.task4_widget = Task4App()
            self.task5_widget = Task5App()
            self.task6_widget = Task6App()
            self.task7_widget = Task7App()
            self.task8_widget = Task8App()
            self.task9_widget = Task9App()

            self.stacked_widget.addWidget(self.task1_widget)
            self.stacked_widget.addWidget(self.task2_widget)
            self.stacked_widget.addWidget(self.task3_widget)
            self.stacked_widget.addWidget(self.task4_widget)
            self.stacked_widget.addWidget(self.task5_widget)
            self.stacked_widget.addWidget(self.task6_widget)
            self.stacked_widget.addWidget(self.task7_widget)
            self.stacked_widget.addWidget(self.task8_widget)
            self.stacked_widget.addWidget(self.task9_widget)

        self.stacked_widget.setCurrentIndex(index)
        # Remove the placeholder label after the first button click
        if self.placeholder:
            self.main_layout.removeWidget(self.placeholder)
            self.placeholder.deleteLater()
            self.placeholder = None

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainApp()
    sys.exit(app.exec_())
