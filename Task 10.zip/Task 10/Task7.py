import sys


from PyQt5.QtWidgets import *

from PyQt5.QtGui import QIcon, QDoubleValidator
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from numpy import deg2rad, cos, sin, tan, sqrt, linspace

ladData = 0
larData = 0
uData = 0
hData = 0
gData = 0


ys = [0]
xs = [0]


angle1 = deg2rad(30)
angle2 = deg2rad(45)
angle3 = deg2rad(60)
angle4 = deg2rad(70.5)
angle5 = deg2rad(78)
angle6 = deg2rad(85)

x1s = []
x2s = []
x3s = []
x4s = []
x5s = []
x6s = []

y1s = []
y2s = []
y3s = []
y4s = []
y5s = []
y6s = []


def min_max(u, g, h, angle):
    if angle == deg2rad(70.5):
        tstationary = (u * sqrt(2)) / g
        xstationary = u * tstationary * cos(angle)

        rstationary = sqrt((u ** 2 * tstationary ** 2) - (g * tstationary ** 3 * u * sin(angle)) + ((1 / 4) * g ** 2 * tstationary ** 4))
        ystationary = h + xstationary * tan(angle) - (g / (2 * u ** 2)) * (1 + (tan(angle)) ** 2) * xstationary ** 2

        return tstationary, xstationary, rstationary, ystationary

    else:
        tmin = ((3 * u) / (2 * g)) * (sin(angle) + sqrt((sin(angle) ** 2) - (8 / 9)))
        tmax = ((3 * u) / (2 * g)) * (sin(angle) - sqrt((sin(angle) ** 2) - (8 / 9)))
        xmin = u * tmin * cos(angle)
        xmax = u * tmax * cos(angle)

        rmax = sqrt((u ** 2 * tmax ** 2) - (g * tmax ** 3 * u * sin(angle)) + ((1 / 4) * g ** 2 * tmax ** 4))
        rmin = sqrt((u ** 2 * tmin ** 2) - (g * tmin ** 3 * u * sin(angle)) + ((1 / 4) * g ** 2 * tmin ** 4))
        ymin = h + xmin * tan(angle) - (g / (2 * u ** 2)) * (1 + (tan(angle)) ** 2) * xmin ** 2
        ymax = h + xmax * tan(angle) - (g / (2 * u ** 2)) * (1 + (tan(angle)) ** 2) * xmax ** 2

        return tmin, tmax, xmin, xmax, rmin, rmax, ymin, ymax


def trajectories(u, h, g, angle, h_below):
    R = ((u ** 2) / g) * (sin(angle) * cos(angle) + cos(angle) * sqrt((sin(angle)) ** 2 + ((2 * g * (h + h_below)) / (u ** 2))))

    # coordinates
    x = linspace(0.0, R, num=200)
    y = []

    for i in range(len(x)):
        y.append(h + x[i] * tan(angle) - (g / (2 * u ** 2)) * (1 + (tan(angle)) ** 2) * x[i] ** 2)

    return x, y, R

def coordinates(u, g, tlim, angle):
    t = linspace(0.0, tlim, num = 200)
    r = []

    for i in range (len(t)):
        r.append(sqrt((u**2 * t[i]**2) - (g * t[i]**3 * u * sin(angle)) + ((1/4) * g**2 * t[i]**4)))

    return t, r




class Task7App(QMainWindow):

    def __init__(self):
        super().__init__()
        self.left = 10
        self.top = 10
        self.title = 'Task 7'
        self.width = 800
        self.height = 800
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        centralWidget = QWidget(self)
        self.setCentralWidget(centralWidget)
        layout = QHBoxLayout(centralWidget)

        # Plot canvas
        self.m = PlotCanvas(self, width=5, height=8)
        layout.addWidget(self.m)

        # Controls layout
        controlsLayout = QVBoxLayout()
        layout.addLayout(controlsLayout)

        uLabel = QLabel("Launch speed", self)
        u = QDoubleSpinBox(self)
        uLabel.setBuddy(u)
        uLabel.move(525,30)
        u.move(675,30)
        u.valueChanged.connect(self.getUData)
        u.valueChanged.connect(self.calc)
        hLabel = QLabel("Launch height", self)
        h = QDoubleSpinBox(self)
        hLabel.setBuddy(h)
        hLabel.move(525, 60)
        h.move(675, 60)
        h.valueChanged.connect(self.getHData)
        h.valueChanged.connect(self.calc)
        gLabel = QLabel("Strength of gravity", self)
        g = QDoubleSpinBox(self)
        gLabel.setBuddy(g)
        gLabel.resize(150,10)
        gLabel.move(525, 90)
        g.move(675, 90)
        g.valueChanged.connect(self.getGData)
        g.valueChanged.connect(self.calc)

        controlsLayout.addWidget(uLabel)
        controlsLayout.addWidget(u)
        controlsLayout.addWidget(hLabel)
        controlsLayout.addWidget(h)
        controlsLayout.addWidget(gLabel)
        controlsLayout.addWidget(g)

        self.show()


    def getUData(self, value):
        global uData
        uData = value

    def getHData(self, value):
        global hData
        hData = value

    def getGData(self, value):
        global gData
        gData = value

    def calc(self):
        global x1s, x2s, x3s, x4s, x5s, x6s
        global y1s, y2s, y3s, y4s, y5s, y6s




        if gData > 0 and uData >0:
            h_below = hData + ((uData ** 2) / (2 * gData)) * (sin(angle6)) * (sin(angle6))
            x1s, y1s, r1Data = trajectories(uData, hData, gData, angle1, h_below)
            x2s, y2s, r2Data = trajectories(uData, hData, gData, angle2, h_below)
            x3s, y3s, r3Data = trajectories(uData, hData, gData, angle3, h_below)
            x4s, y4s, r4Data = trajectories(uData, hData, gData, angle4, h_below)
            x5s, y5s, r5Data = trajectories(uData, hData, gData, angle5, h_below)
            x6s, y6s, r6Data = trajectories(uData, hData, gData, angle6, h_below)

            tstationary, xstationary, rstationary, ystationary = min_max(uData, gData, hData, angle4)
            tmin5, tmax5, xmin5, xmax5, rmin5, rmax5, ymin5, ymax5 = min_max(uData, gData, hData, angle5)
            tmin6, tmax6, xmin6, xmax6, rmin6, rmax6, ymin6, ymax6 = min_max(uData, gData, hData, angle6)

            tlim = tmin6 * 2

            t1s, r1s = coordinates(uData, gData, tlim, angle1)
            t2s, r2s = coordinates(uData, gData, tlim, angle2)
            t3s, r3s = coordinates(uData, gData, tlim, angle3)
            t4s, r4s = coordinates(uData, gData, tlim, angle4)
            t5s, r5s = coordinates(uData, gData, tlim, angle5)
            t6s, r6s = coordinates(uData, gData, tlim, angle6)

            self.m.plot(tstationary, xstationary, rstationary, ystationary, tmin5, tmax5, xmin5, xmax5, rmin5, rmax5, ymin5, ymax5, tmin6, tmax6, xmin6, xmax6, rmin6, rmax6, ymin6, ymax6, r1Data, r2Data, r3Data, r4Data, r5Data, r6Data,r1s, r2s, r3s, r4s, r5s, r6s, t1s, t2s, t3s, t4s, t5s, t6s, y1s, y2s, y3s, y4s, y5s, y6s, tlim)


class PlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=8, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes1 = fig.add_subplot(211)
        self.axes2 = fig.add_subplot(212)
        FigureCanvas.__init__(self, fig)
        self.setParent(parent)
        FigureCanvas.setSizePolicy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)

    def plot(self, tstationary, xstationary, rstationary, ystationary, tmin5, tmax5, xmin5, xmax5, rmin5, rmax5, ymin5, ymax5, tmin6, tmax6, xmin6, xmax6, rmin6, rmax6, ymin6, ymax6, r1Data, r2Data, r3Data, r4Data, r5Data, r6Data,r1s, r2s, r3s, r4s, r5s, r6s, t1s, t2s, t3s, t4s, t5s, t6s, y1s, y2s, y3s, y4s, y5s, y6s, tlim):
        self.axes1.clear()
        self.axes1.plot(t1s, r1s, label ="30")
        self.axes1.plot(t2s, r2s, label ="45")
        self.axes1.plot(t3s, r3s, label ="60")
        self.axes1.plot(t4s, r4s, label ="70.5")
        self.axes1.plot(t5s, r5s, label ="78")
        self.axes1.plot(t6s, r6s, label ="80")
        self.axes1.set_title('Range against Time')
        self.axes1.set_xlim(0, tlim)
        self.axes1.set_ylim(0, max(r1s))

        self.axes2.clear()
        self.axes2.plot(x1s, y1s, "g")
        self.axes2.plot(x2s, y2s, "c")
        self.axes2.plot(x3s, y3s, "m")
        self.axes2.plot(x4s, y4s, "y")
        self.axes2.plot(x5s, y5s, "r")
        self.axes2.plot(x6s, y6s, "b")
        self.axes2.set_title('Y against X')
        self.axes2.set_xlim(0, (max(r1Data, r2Data, r3Data, r4Data, r5Data, r6Data,) + min(r1Data, r2Data, r3Data, r4Data, r5Data, r6Data,)))
        self.axes2.set_ylim((-(max(y6s)), (max(y6s) + (y6s[10]-hData))))

        self.scatter_max4 = self.axes1.scatter(tstationary, rstationary, lw=1, marker="1", s=50, c="#20B2AA", zorder=4)
        self.scatter_max5 = self.axes1.scatter(tmax5, rmax5, lw=1, marker="1", s=50, c="#20B2AA", zorder=4)
        self.scatter_max6 = self.axes1.scatter(tmax6, rmax6, lw=1, marker="1", s=50, c="#20B2AA", zorder=4)
        self.scatter_min5 = self.axes1.scatter(tmin5, rmin5, lw=1, marker="1", s=50, c="#20B2AA", zorder=4)
        self.scatter_min6 = self.axes1.scatter(tmin6, rmin6, lw=1, marker="1", s=50, c="#20B2AA", zorder=4)

        self.scatter_max4_yx = self.axes2.scatter(xstationary, ystationary, lw=1, marker="1", s=50, c="r", zorder=4)
        self.scatter_max5_yx = self.axes2.scatter(xmax5, ymax5, lw=1, marker="1", s=50, c="b", zorder=4)
        self.scatter_max6_yx = self.axes2.scatter(xmax6, ymax6, lw=1, marker="1", s=50, c="red", zorder=4)
        self.scatter_min5_yx = self.axes2.scatter(xmin5, ymin5, lw=1, marker="1", s=50, c="b", zorder=4)
        self.scatter_min6_yx = self.axes2.scatter(xmin6, ymin6, lw=1, marker="1", s=50, c="red", zorder=4)

        self.draw()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Task7App()
    sys.exit(app.exec_())