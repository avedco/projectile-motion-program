import sys
from PyQt5.QtWidgets import *

from PyQt5.QtGui import QIcon, QDoubleValidator
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.animation import FuncAnimation as anim
from matplotlib.animation import FFMpegWriter as writer
from numpy import deg2rad, cos, sin

ladData = 0
uData = 0
hData = 0
gData = 0
tIntervalData = 0
nData = 0
tData = 0

ys = [0]
xs = [0]



class Task8App(QMainWindow):

    def __init__(self):
        super().__init__()
        self.left = 10
        self.top = 10
        self.title = 'Task 8'
        self.width = 800
        self.height = 400
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)

        centralWidget = QWidget(self)
        self.setCentralWidget(centralWidget)

        layout = QGridLayout()
        centralWidget.setLayout(layout)
        self.m = PlotCanvas(self, width=5, height=4)
        layout.addWidget(self.m, 0, 0, 10, 1)
        ladLabel = QLabel("Launch Angle (Degrees)", self)
        lad = QDoubleSpinBox(self)
        ladLabel.setBuddy(lad)
        lad.setMaximum(90)
        ladLabel.resize(150,20)
        lad.valueChanged.connect(self.getLadData)
        lad.valueChanged.connect(self.calc)
        layout.addWidget(lad, 0, 2)
        layout.addWidget(ladLabel, 0, 1)

        uLabel = QLabel("Launch speed", self)
        u = QDoubleSpinBox(self)
        uLabel.setBuddy(u)
        layout.addWidget(u, 1, 2)
        layout.addWidget(uLabel, 1, 1)

        u.valueChanged.connect(self.getUData)
        u.valueChanged.connect(self.calc)
        hLabel = QLabel("Launch height", self)
        h = QDoubleSpinBox(self)
        hLabel.setBuddy(h)
        layout.addWidget(h, 2, 2)
        layout.addWidget(hLabel, 2, 1)

        h.valueChanged.connect(self.getHData)
        h.valueChanged.connect(self.calc)
        gLabel = QLabel("Strength of gravity", self)
        g = QDoubleSpinBox(self)
        gLabel.setBuddy(g)
        gLabel.resize(150,20)
        layout.addWidget(g, 3, 2)
        layout.addWidget(gLabel, 3, 1)

        g.valueChanged.connect(self.getGData)
        g.valueChanged.connect(self.calc)
        tIntervalLabel = QLabel("Time interval", self)
        tInterval = QDoubleSpinBox(self)
        tIntervalLabel.setBuddy(tInterval)
        tIntervalLabel.resize(150, 20)
        layout.addWidget(tInterval, 4, 2)
        layout.addWidget(tIntervalLabel, 4, 1)

        tInterval.valueChanged.connect(self.getTIntervalData)
        tInterval.valueChanged.connect(self.calc)
        nLabel = QLabel("Number of bounces", self)
        n = QSpinBox(self)
        nLabel.setBuddy(n)
        nLabel.resize(150, 20)
        layout.addWidget(n, 5, 2)
        layout.addWidget(nLabel, 5, 1)

        n.valueChanged.connect(self.getNData)
        n.valueChanged.connect(self.calc)


        self.show()

    def getLadData(self, value):
        global ladData
        ladData = value

    def getUData(self, value):
        global uData
        uData = value

    def getHData(self, value):
        global hData
        hData = value

    def getGData(self, value):
        global gData
        gData = value

    def getNData(self, value):
        global nData
        nData = value

    def getTIntervalData(self, value):
        global tIntervalData
        tIntervalData = value


    def calc(self):
        global xs, ys, tData, ladData


        larData = deg2rad(ladData)
        uXData = uData*cos(larData)
        uYData = uData*sin(larData)

        v = uYData
        bounce = 0
        xs = [0]
        ys = [hData]
        tData = 0.0
        x = 0
        y = hData
        C = 0.7


        if nData > 0 and gData > 0 and tIntervalData > 0 and uYData > 0:
            while bounce < nData:
                x += uXData * tIntervalData
                y += (v*tIntervalData) - 0.5*gData*(tIntervalData**2)

                if y <= 0:
                    bounce += 1
                    y = 0
                    v = -C * v
                else:
                    v -= gData*tIntervalData
                xs.append(x)
                ys.append(y)
                tData += tIntervalData

            self.m.plot(xs, ys)


class PlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        FigureCanvas.__init__(self, fig)
        self.setParent(parent)
        FigureCanvas.setSizePolicy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)
        self.ani = None

    def plot(self, xs, ys):
        self.axes.clear()

        # Plot the trajectory line
        line, = self.axes.plot(xs, ys, "k")

        # Initialize the ball as a scatter plot
        self.ball = self.axes.scatter([], [], c="r", s=70, zorder = 4)  # s is for size of the marker

        self.axes.set_title('')
        self.axes.set_xlim(0, max(xs, default=1) + 1)
        self.axes.set_ylim(0, max(ys, default=1) * 1.5)

        def update(frame):
            # Update the trajectory line
            line.set_data(xs[:frame + 1], ys[:frame + 1])

            # Update the ball position if frame is within bounds
            if frame < len(xs):
                self.ball.set_offsets([xs[frame], ys[frame]])

            return line, self.ball

        # Create and save the animation
        self.ani = anim(self.figure, update, frames=len(xs), interval=(1000 / 120), blit=True,
                        repeat=False)  # Adjusted FPS to 30 for smoother playback
        Writer = writer(fps=120)  # Ensure the fps matches the interval for smooth playback
        self.ani.save('animation.mp4', writer=Writer)

        self.draw()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = Task8App()
    window.show()
    sys.exit(app.exec_())