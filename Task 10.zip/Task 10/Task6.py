import sys
from PyQt5.QtWidgets import *
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from numpy import deg2rad, cos, sin, tan, sqrt, format_float_positional, pi
from math import asin,degrees,log

ladData = 0
larData = 0
uData = 0
hData = 0
gData = 0
rMaxData = 0
tMaxData = 0

ys = [0]
xs = [0]
xMaxs = [0]
yMaxs = [0]

class Task6App(QMainWindow):

    def __init__(self):
        super().__init__()
        self.left = 10
        self.top = 10
        self.title = 'Task 6'
        self.width = 900
        self.height = 400
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        centralWidget = QWidget(self)
        self.setCentralWidget(centralWidget)

        layout = QGridLayout()
        centralWidget.setLayout(layout)
        self.m = PlotCanvas(self, width=5, height=4)
        layout.addWidget(self.m, 0, 0, 10, 1)
        ladLabel = QLabel("Launch Angle (Degrees)", self)
        lad = QDoubleSpinBox(self)
        lad.setMaximum(90)
        ladLabel.setBuddy(lad)
        ladLabel.resize(150,20)
        layout.addWidget(ladLabel, 0, 1)
        layout.addWidget(lad,0, 2)
        lad.valueChanged.connect(self.getLadData)
        lad.valueChanged.connect(self.calc)
        uLabel = QLabel("Launch speed", self)
        u = QDoubleSpinBox(self)
        uLabel.setBuddy(u)
        layout.addWidget(uLabel, 1, 1)
        layout.addWidget(u, 1, 2)
        u.valueChanged.connect(self.getUData)
        u.valueChanged.connect(self.calc)
        hLabel = QLabel("Launch height", self)
        h = QDoubleSpinBox(self)
        hLabel.setBuddy(h)
        layout.addWidget(hLabel, 2, 1)
        layout.addWidget(h, 2, 2)
        h.valueChanged.connect(self.getHData)
        h.valueChanged.connect(self.calc)
        gLabel = QLabel("Strength of gravity", self)
        g = QDoubleSpinBox(self)
        gLabel.setBuddy(g)
        gLabel.resize(150,20)
        layout.addWidget(gLabel, 3, 1)
        layout.addWidget(g, 3, 2)
        g.valueChanged.connect(self.getGData)
        g.valueChanged.connect(self.calc)
        self.rMaxLabel = QLabel("Maximum range:", self)
        layout.addWidget(self.rMaxLabel, 4, 1)

        self.rMaxLabel.resize(200,20)
        self.tMaxLabel = QLabel("Maximum time of flight:", self)
        self.tMaxLabel.resize(200,20)
        layout.addWidget(self.tMaxLabel, 5, 1)
        self.aMaxLabel = QLabel("Angle for maximum trajectory:", self)
        self.aMaxLabel.resize(250, 20)
        layout.addWidget(self.aMaxLabel, 6, 1)
        self.sLabel = QLabel("Distance travelled by projectile:", self)
        self.sLabel.resize(250, 20)
        layout.addWidget(self.sLabel, 7, 1)
        self.sMaxLabel = QLabel("Distance travelled by maximum trajectory projectile:", self)
        self.sMaxLabel.resize(350, 20)
        layout.addWidget(self.sMaxLabel, 8, 1)

        self.show()

    def getLadData(self, value):
        global ladData
        ladData = value

    def getUData(self, value):
        global uData
        uData = value

    def getHData(self, value):
        global hData
        hData = value

    def getGData(self, value):
        global gData
        gData = value

    def calc(self):
        global xMaxs, yMaxs
        global xs, ys
        xMaxs.clear()
        yMaxs.clear()
        xs.clear()
        ys.clear()
        larData = deg2rad(ladData)

        if gData >0 and uData >0:
            rData = ((uData * uData) / gData) * (sin(larData) * cos(larData) + cos(larData) * sqrt(sin(larData) * sin(larData) + (2 * gData * hData) / (uData * uData)))


            rMaxData = ((uData*uData)/gData)*sqrt(1+((2*gData*hData)/(uData*uData)))
            tMaxData = (uData/gData)*sqrt(2+(2*gData)/(uData*uData))
            aMaxData = asin(1/(sqrt(2+(2*gData*hData/(uData*uData)))))



            self.rMaxLabel.setText(f"Maximum range: {format_float_positional(rMaxData, precision=3, unique=False, fractional=False, trim='k')}")
            self.tMaxLabel.setText(f"Maximum time of flight: {format_float_positional(tMaxData, precision=3, unique=False, fractional=False, trim='k')}")
            self.aMaxLabel.setText(f"Angle for maximum trajectory: {round(degrees(aMaxData))}")


            if hData > 0  and aMaxData < (pi/2):
                lowerMaxlimit = tan(aMaxData) - (((gData * rMaxData) / (uData ** 2)) * (1 + (tan(aMaxData) ** 2)))
                upperMaxlimit = tan(aMaxData)

                integral_lowerMaxlimit = (0.5 * log(abs(sqrt(1 + lowerMaxlimit ** 2)) + lowerMaxlimit)) + (0.5 * lowerMaxlimit * sqrt(1 + lowerMaxlimit ** 2))
                integral_upperMaxlimit = (0.5 * log(abs(sqrt(1 + upperMaxlimit ** 2)) + upperMaxlimit)) + (0.5 * upperMaxlimit * sqrt(1 + upperMaxlimit ** 2))

                sMaxData = ((uData ** 2) / (gData * (1 + (tan(aMaxData)) ** 2))) * (integral_upperMaxlimit - integral_lowerMaxlimit)
                self.sMaxLabel.setText(f"Distance travelled by maximum trajectory projectile: {round(sMaxData, 1)}")

            else:
                sMaxData = (uData ** 2 / gData) * log(((1 + sin(aMaxData)) / cos(aMaxData)) * (cos(aMaxData) ** 2) + sin(aMaxData))
                self.sMaxLabel.setText(f"Distance travelled by maximum trajectory projectile: {round(sMaxData, 1)}")

            if hData > 0 and larData < (pi/2):
                lowerlimit = tan(larData) - (((gData * rData) / (uData ** 2)) * (1 + (tan(larData) ** 2)))
                upperlimit = tan(larData)

                integral_lowerlimit = (0.5 * log(abs(sqrt(1 + lowerlimit ** 2)) + lowerlimit)) + (0.5 * lowerlimit * sqrt(1 + lowerlimit ** 2))
                integral_upperlimit = (0.5 * log(abs(sqrt(1 + upperlimit ** 2)) + upperlimit)) + (0.5 * upperlimit * sqrt(1 + upperlimit ** 2))

                sData = ((uData ** 2) / (gData * (1 + (tan(larData)) ** 2))) * (integral_upperlimit - integral_lowerlimit)
                self.sLabel.setText(f"Distance travelled by projectile: {round(sData,1)}")
            else:
                sData = (uData ** 2 / gData) * log(((1 + sin(larData)) / cos(larData)) * (cos(larData) ** 2) + sin(larData))
                self.sLabel.setText(f"Distance travelled by projectile: {round(sData,1)}")

            for i in range(101):
                x = rData*i*0.01
                xMax = rMaxData*i*0.01
                xs.append(x)
                xMaxs.append(xMax)
                y = hData + x*tan(larData)-((gData)/(2*uData*uData))*(1+tan(larData)*tan(larData))*x*x
                yMax = hData + xMax * tan(aMaxData) - ((gData) / (2 * uData * uData)) * (1 + tan(aMaxData) * tan(aMaxData)) * xMax * xMax
                ys.append(y)
                yMaxs.append(yMax)

            self.m.plot(xs, ys, xMaxs, yMaxs)
class PlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        FigureCanvas.__init__(self, fig)
        self.setParent(parent)
        FigureCanvas.setSizePolicy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)

    def plot(self, xs, ys, xMaxs, yMaxs):
        self.axes.clear()
        self.axes.plot(xs, ys, "k", label='Trajectory')
        self.axes.plot(xMaxs, yMaxs, "c", label='Maximum trajectory')
        self.axes.set_xlim(left=0, right=(1.1*max(xMaxs)))
        self.axes.set_ylim(bottom=0, top=(1.1*max(max(ys),max(yMaxs))))
        self.axes.legend(loc='best', bbox_to_anchor=(0.5, 1.15), ncol=1)
        self.draw()



if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Task6App()
    sys.exit(app.exec_())