import sys
from PyQt5.QtWidgets import *

from PyQt5.QtGui import QIcon, QDoubleValidator
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
from numpy import deg2rad, cos, sin

ladData = 0
larData = 0
uData = 0
hData = 0
gData = 0

ys = [0]
xs = [0]

class Task1App(QMainWindow):

    def __init__(self):
        super().__init__()
        self.left = 10
        self.top = 10
        self.title = 'Task 1'
        self.width = 800
        self.height = 400
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        centralWidget = QWidget(self)
        self.setCentralWidget(centralWidget)

        layout = QGridLayout()
        centralWidget.setLayout(layout)
        self.m = PlotCanvas(self, width=5, height=4)
        layout.addWidget(self.m, 0, 0, 10, 1)
        ladLabel = QLabel("Launch Angle (Degrees)", self)
        lad = QDoubleSpinBox(self)
        ladLabel.setBuddy(lad)
        lad.setMaximum(90)
        ladLabel.resize(150,20)
        layout.addWidget(ladLabel, 0, 1)
        layout.addWidget(lad, 0, 2)
        lad.valueChanged.connect(self.getLadData)
        lad.valueChanged.connect(self.calc)
        uLabel = QLabel("Launch speed", self)
        u = QDoubleSpinBox(self)
        uLabel.setBuddy(u)
        layout.addWidget(uLabel, 1, 1)
        layout.addWidget(u, 1, 2)
        u.valueChanged.connect(self.getUData)
        u.valueChanged.connect(self.calc)
        hLabel = QLabel("Launch height", self)
        h = QDoubleSpinBox(self)
        hLabel.setBuddy(h)
        layout.addWidget(hLabel, 2, 1)
        layout.addWidget(h, 2, 2)
        h.valueChanged.connect(self.getHData)
        h.valueChanged.connect(self.calc)
        gLabel = QLabel("Strength of gravity", self)
        g = QDoubleSpinBox(self)
        gLabel.setBuddy(g)
        gLabel.resize(150,20)
        layout.addWidget(gLabel, 3, 1)
        layout.addWidget(g, 3, 2)
        g.valueChanged.connect(self.getGData)
        g.valueChanged.connect(self.calc)
        self.show()

    def getLadData(self, value):
        global ladData
        ladData = value

    def getUData(self, value):
        global uData
        uData = value

    def getHData(self, value):
        global hData
        hData = value

    def getGData(self, value):
        global gData
        gData = value

    def calc(self):
        global xs, ys
        xs.clear()
        ys.clear()
        larData = deg2rad(ladData)
        vx = uData*cos(larData)
        uy = uData*sin(larData)
        for i in range(1000000):
            t = i * 0.0001
            y = hData + uy*t - 0.5*gData*t*t
            if y<0:
                break
            ys.append(y)
            x = vx*t
            xs.append(x)
        self.m.plot(xs, ys)

class PlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        FigureCanvas.__init__(self, fig)
        self.setParent(parent)
        FigureCanvas.setSizePolicy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)

    def plot(self, xs, ys):
        self.axes.clear()
        self.axes.plot(xs, ys, "k")
        self.axes.set_title('Simple Projectile Motion')
        self.axes.set_xlim(left=0)
        self.axes.set_ylim(bottom=0)
        self.draw()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Task1App()
    sys.exit(app.exec_())