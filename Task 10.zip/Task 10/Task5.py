import sys
from PyQt5.QtWidgets import *
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from math import atan, cos, tan, sqrt, ceil, asin
from numpy import linspace

uData = 0
hData = 0
gData = 0
xtData = 0
ytData = 0
rMaxData = 0
discrim = 0

lys = [0]
hys = [0]
mys = [0]
bys = [0]
bxs = [0]
xs = [0]
xMaxs = [0]
yMaxs = [0]

class Task5App(QMainWindow):

    def __init__(self):
        super().__init__()
        self.left = 10
        self.top = 10
        self.title = 'Task 5'
        self.width = 1000
        self.height = 400
        self.initUI()

    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        centralWidget = QWidget(self)
        self.setCentralWidget(centralWidget)

        layout = QGridLayout()
        centralWidget.setLayout(layout)
        self.m = PlotCanvas(self, width=5, height=4)
        layout.addWidget(self.m, 0, 0, 10, 1)

        xtLabel = QLabel("X", self)
        xt = QDoubleSpinBox(self)
        xt.setMaximum(10000)
        xtLabel.setBuddy(xt)
        xtLabel.resize(150,20)
        layout.addWidget(xtLabel, 0, 1)
        layout.addWidget(xt, 0, 2)
        xt.valueChanged.connect(self.getxtData)
        xt.valueChanged.connect(self.calc)

        ytLabel = QLabel("Y", self)
        yt = QDoubleSpinBox(self)
        yt.setMaximum(10000)
        ytLabel.setBuddy(yt)
        ytLabel.resize(150, 20)
        layout.addWidget(ytLabel, 1, 1)
        layout.addWidget(yt, 1, 2)
        yt.valueChanged.connect(self.getytData)
        yt.valueChanged.connect(self.calc)

        uLabel = QLabel("Launch speed", self)
        self.u = QDoubleSpinBox(self)
        self.u.setMaximum(1000)
        self.u.setToolTip("Minimum speed is ")
        uLabel.setBuddy(self.u)
        layout.addWidget(uLabel, 2, 1)
        layout.addWidget(self.u, 2, 2)
        self.u.valueChanged.connect(self.getUData)
        self.u.valueChanged.connect(self.calc)

        hLabel = QLabel("Launch height", self)
        h = QDoubleSpinBox(self)
        h.setMaximum(10000)
        hLabel.setBuddy(h)
        layout.addWidget(hLabel, 3, 1)
        layout.addWidget(h, 3, 2)
        h.valueChanged.connect(self.getHData)
        h.valueChanged.connect(self.calc)

        gLabel = QLabel("Strength of gravity", self)
        g = QDoubleSpinBox(self)
        gLabel.setBuddy(g)
        gLabel.resize(150,20)
        layout.addWidget(gLabel, 4, 1)
        layout.addWidget(g, 4, 2)
        g.valueChanged.connect(self.getGData)
        g.valueChanged.connect(self.calc)

        self.umLabel = QLabel("Minimum Launch Speed:", self)
        layout.addWidget(self.umLabel, 5, 1)

        self.umLabel.resize(200, 20)


        self.dLabel = QLabel("Discriminant: ", self)
        self.dLabel.resize(200, 20)
        layout.addWidget(self.dLabel, 6, 1)

        self.ahrLabel = QLabel("High ball angle: ", self)
        self.ahrLabel.resize(200, 20)
        layout.addWidget(self.ahrLabel, 7, 1)

        self.ahtLabel = QLabel("High ball time of flight: ", self)
        self.ahtLabel.resize(200, 20)
        layout.addWidget(self.ahtLabel, 8, 1)

        self.alrLabel = QLabel("Low ball angle: ", self)
        self.alrLabel.resize(200, 20)
        layout.addWidget(self.alrLabel, 9, 1)

        self.altLabel = QLabel("Low ball time of flight: ", self)
        self.altLabel.resize(200, 20)
        layout.addWidget(self.altLabel, 10, 1)

        self.amrLabel = QLabel("Minimum speed angle: ", self)
        self.amrLabel.resize(200, 20)
        layout.addWidget(self.amrLabel, 11, 1)

        self.amtLabel = QLabel("Minimum speed time of flight: ", self)
        self.amtLabel.resize(250, 20)
        layout.addWidget(self.amtLabel, 12, 1)

        self.show()

    def getxtData(self, value):
        global xtData
        xtData = value

    def getytData(self, value):
        global ytData
        ytData = value

    def getUData(self, value):
        global uData
        uData = value

    def getHData(self, value):
        global hData
        hData = value

    def getGData(self, value):
        global gData
        gData = value

    def calc(self):
        global aHR, aLR
        global TData, discrim
        global bxs

        uMin = sqrt(gData) * sqrt(ytData - hData + sqrt(xtData * xtData + (ytData - hData) * (ytData - hData)))
        self.u.setMinimum((ceil(uMin*100)/100))
        self.u.setToolTip(f'Minimum speed is {(ceil(uMin*100)/100)}')
        self.umLabel.setText(f'Minimum Launch Speed: {(ceil(uMin*100)/100)}')

        if xtData > 0 and uData > 0 and gData>0:
            umr = atan((ytData - hData + sqrt(xtData * xtData + (ytData - hData) * (ytData - hData))) / xtData)
            self.amrLabel.setText(f'Minimum speed angle: {round(umr, 2)}')
            amt = xtData / (uData * cos(umr))
            self.amtLabel.setText(f'Minimum speed time of flight: {round(amt, 2)}')

            a = (gData / (2 * uData * uData)) * xtData * xtData
            b = -xtData
            c = (ytData - hData + ((gData * xtData * xtData) / (2 * uData * uData)))
            discrim = b * b - 4 * a * c
            self.dLabel.setText(f"Discriminant: {round(discrim)}")

            rMaxData = ((uData * uData) / gData) * sqrt(1 + ((2 * gData * hData) / (uData * uData)))
            aMaxData = asin(1 / (sqrt(2 + (2 * gData * hData / (uData * uData)))))


            if discrim >= 0:
                aHR = atan(((-b + sqrt(discrim)) / (2 * a)))
                self.ahrLabel.setText(f'High ball angle: {round(aHR, 2)}')
                aht = xtData / (uData * cos(aHR))
                self.ahtLabel.setText(f'High ball time of flight: {round(aht, 2)}')
                aLR = atan(((-b - sqrt(discrim)) / (2 * a)))
                self.alrLabel.setText(f'Low ball angle: {round(aLR, 2)}')
                alt = xtData / (uData * cos(aLR))
                self.altLabel.setText(f'Low ball time of flight: {round(alt, 2)}')

            xs.clear()
            lys.clear()
            mys.clear()
            hys.clear()
            xMaxs.clear()
            yMaxs.clear()
            bys.clear()


            boundRange = ((uData**2)/gData) * sqrt(1 + (2*gData*hData)/(uData**2))
            bxs = linspace(0, boundRange, num = 100)
            for i in range(len(bxs)):
                by = hData + ((uData ** 2) / (2 * gData)) - ((gData * bxs[i] ** 2) / (2 * uData ** 2))
                bys.append(by)
            for i in range(101):
                t = i * 0.01
                x = t * xtData

                xMax = rMaxData * i * 0.01
                xMaxs.append(xMax)
                yMax = hData + xMax * tan(aMaxData) - ((gData) / (2 * uData * uData)) * (1 + tan(aMaxData) * tan(aMaxData)) * xMax * xMax
                yMaxs.append(yMax)

                if uData == ceil(uMin*100)/100:
                    ly = hData + x * tan(umr) - (gData / (2 * uMin * uMin)) * (1 + tan(umr) * tan(umr)) * x * x
                    hy = hData + x * tan(umr) - (gData / (2 * uMin * uMin)) * (1 + tan(umr) * tan(umr)) * x * x
                    my = hData + x * tan(umr) - (gData / (2 * uMin * uMin)) * (1 + tan(umr) * tan(umr)) * x * x

                else:
                    ly = hData + x * tan(aLR) - (gData / (2 * uData * uData)) * (1 + tan(aLR) * tan(aLR)) * x * x
                    hy = hData + x * tan(aHR) - (gData / (2 * uData * uData)) * (1 + tan(aHR) * tan(aHR)) * x * x
                    my = hData + x * tan(umr) - (gData / (2 * uMin * uMin)) * (1 + tan(umr) * tan(umr)) * x * x


                lys.append(ly)
                hys.append(hy)
                mys.append(my)


                xs.append(x)

            self.m.plot(xs, lys, hys, mys, bys, bxs, xtData, ytData, xMaxs, yMaxs)
        else:
            self.dLabel.setText("Discriminant:")
class PlotCanvas(FigureCanvas):

    def __init__(self, parent=None, width=5, height=4, dpi=100):
        fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = fig.add_subplot(111)
        FigureCanvas.__init__(self, fig)
        self.setParent(parent)
        FigureCanvas.setSizePolicy(self, QSizePolicy.Expanding, QSizePolicy.Expanding)
        FigureCanvas.updateGeometry(self)

    def plot(self, xs, lys, hys, mys, bys, bxs, xt, yt, xMaxs, yMaxs):
        self.axes.clear()
        self.axes.plot(xs, mys, "k", label='Min U')
        self.axes.plot(xs, hys, "b", label='High ball')
        self.axes.plot(xs, lys, "c", label='Low ball')
        self.axes.plot(bxs, bys, "g", label='Bounding')
        self.axes.plot(xMaxs, yMaxs, "m", label='Maximum trajectory')
        self.axes.plot([xt], [yt], "yo", label="Target")
        self.axes.set_xlim(left=0, right=(1.2 * max(max(bxs), max(xMaxs))))
        self.axes.set_ylim(bottom=0, top=(1.2 * max(max(bys), max(yMaxs))))
        self.axes.legend(loc='upper left', bbox_to_anchor=(0.5, 1.15), ncol=1)  # Add the legend to the plot
        self.draw()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = Task5App()
    sys.exit(app.exec_())
